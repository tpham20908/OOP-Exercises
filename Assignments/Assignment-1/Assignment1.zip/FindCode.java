class FindCode {
  public static void main(String[] args) {
  // 1. Find the code for the registered symbol (ɰ)
  // 2. Create a variable of type char and assign it the unicode value for that symbol.
  char symbol = '\u0270';
  // 3. Display in on screen.
  System.out.println(symbol);
  // For Unicode refer: https://unicode-table.com/en/#basic-latin
  }
}